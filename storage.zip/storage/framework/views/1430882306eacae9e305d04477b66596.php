

<script src="<?php echo URL::asset('/vendors/jquery/dist/jquery.min.js'); ?>"></script>


<script src="<?php echo URL::asset('/vendors/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>


<script src="<?php echo URL::asset('/vendors/nprogress/nprogress.js'); ?>"></script>

<!-- bootstrap-progressbar -->
<script src="<?php echo URL::asset('/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js'); ?>"></script>


<script src="<?php echo URL::asset('/vendors/parsleyjs/dist/parsley.min.js'); ?>"></script>


<script src="<?php echo URL::asset('/vendors/select2/dist/js/select2.full.min.js'); ?>"></script>


<script src="<?php echo URL::asset('/vendors/moment/min/moment.min.js'); ?>"></script>


<script src="<?php echo URL::asset('/vendors/pikaday/js/pikaday.js'); ?>"></script>
<script src="<?php echo URL::asset('/vendors/pikaday/js/pikaday.jquery.js'); ?>"></script>


<script src="<?php echo URL::asset('/vendors/pnotify/dist/pnotify.js'); ?>"></script>
<script src="<?php echo URL::asset('/vendors/pnotify/dist/pnotify.buttons.js'); ?>"></script>
<script src="<?php echo URL::asset('/vendors/pnotify/dist/pnotify.nonblock.js'); ?>"></script>

 <!-- datepicker -->
<script src="<?php echo e(URL::asset('vendors/datepicker/bootstrap-datepicker.js')); ?>"></script>

<!-- timepicker -->
<script src="<?php echo e(URL::asset('vendors/timepicker/bootstrap-timepicker.min.js')); ?>"></script>

 <!-- Tokenizer -->
<script src="<?php echo e(URL::asset('vendors/tokenizer/bootstrap-tokenfield.min.js')); ?>"></script>


<script src="<?php echo URL::asset('/vendors/iCheck/icheck.min.js'); ?>"></script>


<script src="<?php echo URL::asset('/js/app.js'); ?>"></script>


<script src="<?php echo URL::asset('/js/resource.js'); ?>"></script>
<?php /**PATH F:\Proyek\Testing\timetable\penjadwalan-otomatis-akuntansi\resources\views/partials/scripts.blade.php ENDPATH**/ ?>