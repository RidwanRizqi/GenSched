<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <?php if(count($timeslots)): ?>
        <table class="table table-bordered">
            <thead>
                <tr class="table-head">
                    <th style="width: 90%">Period</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $timeslots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeslot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($timeslot->time); ?></td>
                    <td>
                    <button class="btn btn-primary btn-sm resource-update-btn" data-id="<?php echo e($timeslot->id); ?>"><i class="fa fa-pencil"></i></button>
                    <button class="btn btn-danger btn-sm resource-delete-btn" data-id="<?php echo e($timeslot->id); ?>"><i class="fa fa-trash-o"></i></button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="no-data text-center">
            <p>No matching data was found</p>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH F:\Proyek\Testing\timetable\penjadwalan-otomatis-akuntansi\resources\views/timeslots/table.blade.php ENDPATH**/ ?>