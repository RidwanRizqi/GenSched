<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <?php if(count($courses)): ?>
        <table class="table table-bordered">
            <thead>
                <tr class="table-head">
                    <th style="width: 30%">Kode Matkul</th>
                    <th style="width: 30%">Name</th>
                    <th style="width: 30%">Dosen</th>
                    <th style="width: 10%">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($course->course_code); ?></td>
                    <td><?php echo e($course->name); ?></td>
                    <td>
                        <ul>
                        <?php $__currentLoopData = $course->professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($professor->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td>
                    <button class="btn btn-primary btn-sm resource-update-btn" data-id="<?php echo e($course->id); ?>"><i class="fa fa-pencil"></i></button>
                    <button class="btn btn-danger btn-sm resource-delete-btn" data-id="<?php echo e($course->id); ?>"><i class="fa fa-trash-o"></i></button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
         <div id="pagination">
            <?php echo $courses->render(); ?>

        </div>
        <?php else: ?>
        <div class="no-data text-center">
            <p>No matching data was found</p>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH F:\Proyek\Testing\timetable\timetable-generator\resources\views/courses/table.blade.php ENDPATH**/ ?>