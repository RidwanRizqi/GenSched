<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <?php if(count($rooms)): ?>
        <table class="table table-bordered">
            <thead>
                <tr class="table-head">
                    <th style="width: 50%">Nama</th>
                    <th style="width: 40%">Kapasitas</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($room->name); ?></td>
                    <td><?php echo e($room->capacity); ?></td>
                    <td>
                    <button class="btn btn-primary btn-sm resource-update-btn" data-id="<?php echo e($room->id); ?>"><i class="fa fa-pencil"></i></button>
                    <button class="btn btn-danger btn-sm resource-delete-btn" data-id="<?php echo e($room->id); ?>"><i class="fa fa-trash-o"></i></button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
         <div id="pagination">
            <?php echo $rooms->render(); ?>

        </div>
        <?php else: ?>
        <div class="no-data text-center">
            <p>No matching data was found</p>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH F:\Proyek\Testing\timetable\penjadwalan-otomatis-akuntansi\resources\views/rooms/table.blade.php ENDPATH**/ ?>