<div class="row">
	<div class="col-lg-10 col-md-10 col-sm-10 col-lg-offset-1 col-md-offset-1 col-sm-offset-1 alert alert-danger modal-error-div hidden">
		<a class="close" data-dismiss="alert" aria-label="close">&times;</a>
		<p>Whoops! There were some errors. Please fix them:</p>
		<ul></ul>
	</div>
</div><?php /**PATH F:\Proyek\Testing\timetable\penjadwalan-otomatis-akuntansi\resources\views/partials/modal_errors.blade.php ENDPATH**/ ?>