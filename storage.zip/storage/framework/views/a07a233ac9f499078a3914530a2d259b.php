

<?php $__env->startSection('title'); ?>
Classes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xs-12 col-sm-12 col-md-10 col-lg-10 page-container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 page-title">
            <h1><span class="fa fa-users"></span> Kelas</h1>
        </div>
    </div>

    <div class="menubar">
        <?php echo $__env->make('partials.menu_bar', ['buttonTitle' => 'Tambah Kelas Baru'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="page-body" id="resource-container">
        <?php echo $__env->make('classes.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php echo $__env->make('classes.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(URL::asset('/js/classes/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Proyek\Testing\timetable\timetable-generator\resources\views/classes/index.blade.php ENDPATH**/ ?>