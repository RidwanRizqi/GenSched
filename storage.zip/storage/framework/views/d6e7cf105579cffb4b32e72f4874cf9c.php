
<link href="<?php echo URL::asset('/vendors/bootstrap/dist/css/bootstrap.min.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/normalize-css/normalize.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/iCheck/skins/flat/green.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/nprogress/nprogress.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/animate.css/animate.min.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/pikaday/css/pikaday.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/select2/dist/css/select2.min.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/pnotify/dist/pnotify.css'); ?>" rel="stylesheet">
<link href="<?php echo URL::asset('/vendors/pnotify/dist/pnotify.buttons.css'); ?>" rel="stylesheet">
<link href="<?php echo URL::asset('/vendors/pnotify/dist/pnotify.nonblock.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/vendors/tokenizer/bootstrap-tokenfield.min.css'); ?>" rel="stylesheet">


<link href="<?php echo URL::asset('/css/app.css'); ?>" rel="stylesheet">

<!-- Date Picker -->
<link rel="stylesheet" href="<?php echo e(URL::asset('vendors/datepicker/datepicker3.css')); ?>">

<!-- Time Picker -->
<link rel="stylesheet" href="<?php echo e(URL::asset('vendors/timepicker/bootstrap-timepicker.min.css')); ?>">

<?php /**PATH F:\Proyek\Testing\timetable\penjadwalan-otomatis-akuntansi\resources\views/partials/styles.blade.php ENDPATH**/ ?>