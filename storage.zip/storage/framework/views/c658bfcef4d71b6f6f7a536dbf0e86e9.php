<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <?php if(count($professors)): ?>
        <table class="table table-bordered">
            <thead>
                <tr class="table-head">
                    <th style="width: 20%">Nama</th>
                    <th style="width: 20%">Email</th>
                    <th style="width: 30%">Mata Kuliah</th>
                    <th style="width: 20%">Unavailable Periods</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($professor->name); ?></td>
                    <td><?php echo e($professor->email); ?></td>
                    <td>
                        <?php if(count($professor->courses)): ?>
                            <ul>
                                <?php $__currentLoopData = $professor->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($course->course_code . " " . $course->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>No courses added yet</p>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(count($professor->unavailable_timeslots)): ?>
                            <ul>
                                <?php $__currentLoopData = $professor->unavailable_timeslots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($period->day->name . " " . $period->timeslot->time); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>No unavailable periods</p>
                        <?php endif; ?>
                    </td>
                    <td>
                    <button class="btn btn-primary btn-sm resource-update-btn" data-id="<?php echo e($professor->id); ?>"><i class="fa fa-pencil"></i></button>
                    <button class="btn btn-danger btn-sm resource-delete-btn" data-id="<?php echo e($professor->id); ?>"><i class="fa fa-trash-o"></i></button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
         <div id="pagination">
            <?php echo $professors->render(); ?>

        </div>
        <?php else: ?>
        <div class="no-data text-center">
            <p>No matching data was found</p>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH F:\Proyek\Testing\timetable\timetable-generator\resources\views/professors/table.blade.php ENDPATH**/ ?>