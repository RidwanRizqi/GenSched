<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 colxs-12">
        <?php if(count($timetables)): ?>
        <table class="table table-bordered">
            <thead>
                <tr class="table-head">
                    <td>Nama</td>
                    <td>Status</td>
                    <td style="width: 10%">Print</td>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timetable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($timetable->name); ?></td>
                    <td><?php echo e($timetable->status); ?></td>
                    <td>
                        <?php if($timetable->file_url): ?>
                        <a href="<?php echo e(URL::to('/timetables/view/' . $timetable->id)); ?>"
                           class="btn btn-sm btn-primary print-btn"
                        data-id="<?php echo e($timetable->id); ?>"><span class="fa fa-print"></span> PRINT</a>
                        <?php else: ?>
                        N/A
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
         <div id="pagination">
            <?php echo $timetables->render(); ?>

        </div>
        <?php else: ?>
        <div class="no-data text-center">
            <p>Jadwal Belum digenerate</p>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH F:\Proyek\Testing\timetable\penjadwalan-otomatis-akuntansi\resources\views/dashboard/timetables.blade.php ENDPATH**/ ?>