<?php if(session('status')): ?>
	<div class="alert alert-success fade-in">
		<a class="close" data-dismiss="alert" aria-label="close">&times;</a>

		<p><?php echo e(session('status')); ?></p>
	</div>
<?php endif; ?>

<?php if($errors->any()): ?>
	<div class="alert alert-danger fade-in">
		<a class="close" data-dismiss="alert" aria-label="close">&times;</a>

		<p>Whoops! There were some errors. Please fix them:</p>

		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
<?php /**PATH F:\Proyek\Testing\timetable\timetable-generator\resources\views/errors/form_errors.blade.php ENDPATH**/ ?>